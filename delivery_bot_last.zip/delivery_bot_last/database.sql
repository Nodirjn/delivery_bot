-- Categories
INSERT INTO categories (name) 
VALUES ("Osh"), ("Ichimliklar");

-- Products
INSERT INTO products (category_id, name, price, description, photo)
VALUES
    (13, "Oddiy osh.", 34000.00, "🍽️ Osh lazer gruchiga damlangan, 🍗 200 gram gosht,", "https://shorturl.at/aRfe9"),
    (13, "To'y oshi.", 37000.00, "🍽️ Osh lazer gruchiga damlangan, 🍗 200 gram gosht,🥩 1ta qazi, 🥚 2 ta bedana tuqum", "https://shorturl.at/hTmCM"),
    (14, "Coca-Cola 0.5 New.", 7000.00, "Coca Cola tarkibida: Karbonatlangan suv, Karamel rang beruvchi (E150d)", "https://shorturl.at/4tWWr"),
    (14, "Coca-Cola 1.0 New.", 11000.00, "Coca cola tarkibida: Natural lazzatlar (Coca-Cola brendining maxfiy aralashmasi), Citric kislota", "https://shorturl.at/wPcvv"),
    (14, "Sprite 1.0 L", 11000.00, "Bitta sprite so'radi, ob keldim ...", "https://shorturl.at/2MHbs");



DELETE FROM categories WHERE name = 'Ichimliklar';
DELETE FROM categories WHERE name = 'Osh';