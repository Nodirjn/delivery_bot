from aiogram.dispatcher.router import Router

router = Router()
